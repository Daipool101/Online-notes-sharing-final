# Online Notes Sharing System

A comprehensive web-based application designed to facilitate academic collaboration among students by providing a centralized platform for sharing, discovering, and downloading educational notes and resources.

## Table of Contents

- [Project Overview](#project-overview)
- [Features](#features)
- [System Requirements](#system-requirements)
- [Installation and Setup](#installation-and-setup)
- [Running the Application](#running-the-application)
- [Project Structure](#project-structure)
- [API Documentation](#api-documentation)
- [Database Schema](#database-schema)
- [User Guide](#user-guide)
- [Admin Guide](#admin-guide)
- [Troubleshooting](#troubleshooting)
- [Contributing](#contributing)

## Project Overview

The Online Notes Sharing System addresses the common challenge faced by students in accessing and sharing academic resources. Traditional methods of note sharing through messaging apps or physical copies are inefficient and disorganized. This platform provides a modern, web-based solution that enables students to upload, categorize, search, and download academic notes seamlessly.

### Key Objectives

- **Centralized Platform**: Provide a single location for all academic note sharing activities
- **Enhanced Collaboration**: Foster academic collaboration among students across different courses and semesters
- **Quality Assurance**: Implement admin moderation to ensure high-quality content
- **Easy Access**: Enable quick search and retrieval of relevant academic materials
- **User-Friendly Interface**: Offer an intuitive, responsive web interface accessible on all devices

## Features

### Core Functionality

- **User Authentication**: Secure registration and login system with session management
- **File Upload**: Support for multiple file formats (PDF, DOC, DOCX, PPT, PPTX) with size limits
- **Advanced Search**: Search notes by title, description, subject, course, and semester
- **Content Moderation**: Admin approval system for uploaded content
- **Download Tracking**: Monitor download statistics for uploaded notes
- **Responsive Design**: Mobile-friendly interface that works across all devices

### User Features

- **Personal Dashboard**: View and manage uploaded notes
- **Browse Notes**: Explore approved notes with filtering options
- **Upload Notes**: Submit academic materials with detailed metadata
- **Download Notes**: Access approved content instantly

### Administrative Features

- **Content Approval**: Review and approve/reject uploaded notes
- **User Management**: Monitor user activities and registrations
- **System Analytics**: Track upload and download statistics

## System Requirements

### Software Requirements

#### Backend Requirements
- **Python**: Version 3.8 or higher
- **Flask**: Web framework for Python
- **SQLAlchemy**: Database ORM
- **Flask-CORS**: Cross-origin resource sharing support
- **Werkzeug**: WSGI utility library for password hashing

#### Frontend Requirements
- **HTML5**: Modern web standards
- **CSS3**: Advanced styling with responsive design
- **JavaScript (ES6+)**: Modern JavaScript features
- **Font Awesome**: Icon library for UI elements

#### Database Requirements
- **SQLite**: Default database (included with Python)
- **MySQL**: Optional production database (can be configured)

### Hardware Requirements

#### Minimum Requirements
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 1GB free space for application and uploaded files
- **Processor**: Any modern CPU (Intel i3 or equivalent)

#### Recommended Requirements
- **RAM**: 8GB or higher for optimal performance
- **Storage**: 10GB+ for extensive file uploads
- **Processor**: Intel i5 or equivalent for better performance

### Development Environment
- **VS Code**: Primary development environment
- **Python Extension**: For Python development support
- **Live Server Extension**: For frontend development (optional)
- **Git**: Version control system

## Installation and Setup

### Prerequisites

Before setting up the Online Notes Sharing System, ensure you have the following installed on your system:

1. **Python 3.8+**: Download from [python.org](https://python.org)
2. **Git**: Download from [git-scm.com](https://git-scm.com)
3. **VS Code**: Download from [code.visualstudio.com](https://code.visualstudio.com)

### Step-by-Step Installation

#### 1. Clone or Download the Project

If you have the project files, extract them to your desired location. If using Git:

```bash
git clone <repository-url>
cd online_notes_sharing_system
```

#### 2. Open in VS Code

1. Launch VS Code
2. Open the project folder: `File > Open Folder`
3. Navigate to and select the `online_notes_sharing_system` directory

#### 3. Backend Setup

Navigate to the backend directory and set up the Flask application:

```bash
cd backend/notes_sharing_backend
```

##### Create Virtual Environment

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate
```

##### Install Dependencies

```bash
pip install -r requirements.txt
```

If the requirements.txt is missing or you encounter issues, install dependencies manually:

```bash
pip install flask flask-sqlalchemy flask-cors werkzeug
```

#### 4. Database Initialization

The application uses SQLite by default and will automatically create the database on first run. The database file will be created at:
```
backend/notes_sharing_backend/src/database/app.db
```

#### 5. Create Upload Directory

Create the uploads directory for file storage:

```bash
mkdir -p src/uploads
```

### Configuration

#### Environment Variables (Optional)

You can create a `.env` file in the backend directory for custom configuration:

```env
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///app.db
MAX_CONTENT_LENGTH=16777216
UPLOAD_FOLDER=uploads
```

#### Database Configuration

The application is pre-configured to use SQLite. To use MySQL instead:

1. Install MySQL connector:
```bash
pip install pymysql
```

2. Update the database URI in `src/main.py`:
```python
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://username:password@localhost/notes_sharing_db'
```

## Running the Application

### Development Mode

#### 1. Start the Backend Server

From the `backend/notes_sharing_backend` directory with the virtual environment activated:

```bash
python src/main.py
```

The server will start on `http://localhost:5000` by default.

#### 2. Access the Application

Open your web browser and navigate to:
```
http://localhost:5000
```

### VS Code Integration

#### Using VS Code Terminal

1. Open VS Code terminal: `Terminal > New Terminal`
2. Navigate to the backend directory:
```bash
cd backend/notes_sharing_backend
```
3. Activate virtual environment and run:
```bash
source venv/bin/activate  # On Windows: venv\Scripts\activate
python src/main.py
```

#### Using VS Code Debugger

1. Create a `.vscode/launch.json` file in the project root:
```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Python: Flask",
            "type": "python",
            "request": "launch",
            "program": "${workspaceFolder}/backend/notes_sharing_backend/src/main.py",
            "console": "integratedTerminal",
            "cwd": "${workspaceFolder}/backend/notes_sharing_backend",
            "env": {
                "FLASK_ENV": "development"
            }
        }
    ]
}
```

2. Press `F5` or use `Run > Start Debugging`

### Default Admin Account

The application automatically creates a default admin account on first run:

- **Username**: `admin`
- **Password**: `admin123`
- **Email**: `admin@notessharing.com`

**Important**: Change the admin password immediately after first login for security.

## Project Structure

```
online_notes_sharing_system/
├── README.md
├── backend/
│   └── notes_sharing_backend/
│       ├── venv/                    # Virtual environment
│       ├── requirements.txt         # Python dependencies
│       └── src/
│           ├── main.py             # Application entry point
│           ├── database/
│           │   └── app.db          # SQLite database
│           ├── models/
│           │   ├── user.py         # User model
│           │   └── note.py         # Note model
│           ├── routes/
│           │   ├── auth.py         # Authentication routes
│           │   ├── notes.py        # Notes management routes
│           │   └── user.py         # User management routes
│           ├── static/             # Frontend files
│           │   ├── index.html      # Main HTML file
│           │   ├── styles.css      # CSS styles
│           │   └── script.js       # JavaScript functionality
│           └── uploads/            # Uploaded files storage
├── frontend/                       # Original frontend directory (reference)
└── database/                       # Database scripts (reference)
```

### Key Files Description

#### Backend Files

- **`main.py`**: Flask application entry point with configuration and route registration
- **`models/user.py`**: User model with authentication methods
- **`models/note.py`**: Note model with file metadata
- **`routes/auth.py`**: Authentication endpoints (login, register, logout)
- **`routes/notes.py`**: Note management endpoints (upload, browse, download)
- **`routes/user.py`**: User management endpoints

#### Frontend Files

- **`index.html`**: Single-page application with all UI components
- **`styles.css`**: Responsive CSS with modern design
- **`script.js`**: JavaScript for API communication and UI interactions

## API Documentation

The application provides a RESTful API for all operations. All endpoints return JSON responses.

### Authentication Endpoints

#### POST /api/auth/register
Register a new user account.

**Request Body:**
```json
{
    "username": "string (min 3 chars)",
    "email": "string (valid email)",
    "password": "string (min 6 chars)"
}
```

**Response (201):**
```json
{
    "message": "User registered successfully",
    "user": {
        "id": 1,
        "username": "john_doe",
        "email": "john@example.com",
        "is_admin": false,
        "registration_date": "2024-01-01T00:00:00"
    }
}
```

#### POST /api/auth/login
Authenticate user and create session.

**Request Body:**
```json
{
    "username": "string (username or email)",
    "password": "string"
}
```

**Response (200):**
```json
{
    "message": "Login successful",
    "user": {
        "id": 1,
        "username": "john_doe",
        "email": "john@example.com",
        "is_admin": false
    }
}
```

#### POST /api/auth/logout
End user session.

**Response (200):**
```json
{
    "message": "Logged out successfully"
}
```

#### GET /api/auth/check-auth
Check current authentication status.

**Response (200):**
```json
{
    "authenticated": true,
    "user": {
        "id": 1,
        "username": "john_doe",
        "is_admin": false
    }
}
```

### Notes Endpoints

#### POST /api/upload
Upload a new note (requires authentication).

**Request:** Multipart form data
- `title`: string (required)
- `subject`: string (required)
- `course`: string (required)
- `semester`: string (required)
- `description`: string (optional)
- `file`: file (required, PDF/DOC/DOCX/PPT/PPTX)

**Response (201):**
```json
{
    "message": "Note uploaded successfully",
    "note": {
        "id": 1,
        "title": "Introduction to Python",
        "subject": "Computer Science",
        "course": "CS101",
        "semester": "Fall 2024",
        "is_approved": false
    }
}
```

#### GET /api/notes
Browse approved notes with optional filtering.

**Query Parameters:**
- `page`: integer (default: 1)
- `per_page`: integer (default: 10)
- `subject`: string (optional)
- `course`: string (optional)
- `semester`: string (optional)
- `search`: string (optional)

**Response (200):**
```json
{
    "notes": [
        {
            "id": 1,
            "title": "Introduction to Python",
            "subject": "Computer Science",
            "course": "CS101",
            "semester": "Fall 2024",
            "uploader_name": "john_doe",
            "download_count": 5,
            "is_approved": true
        }
    ],
    "total": 1,
    "pages": 1,
    "current_page": 1,
    "per_page": 10
}
```

#### GET /api/notes/{id}/download
Download a specific note file.

**Response:** File download with appropriate headers.

#### GET /api/my-notes
Get current user's uploaded notes (requires authentication).

**Response:** Similar to `/api/notes` but includes user's own notes regardless of approval status.

### Admin Endpoints

#### GET /api/admin/pending-notes
Get notes pending approval (requires admin authentication).

**Response (200):**
```json
{
    "notes": [
        {
            "id": 2,
            "title": "Advanced Algorithms",
            "subject": "Computer Science",
            "uploader_name": "jane_doe",
            "is_approved": false
        }
    ]
}
```

#### POST /api/admin/notes/{id}/approve
Approve a pending note (requires admin authentication).

**Response (200):**
```json
{
    "message": "Note approved successfully",
    "note": {
        "id": 2,
        "is_approved": true
    }
}
```

#### DELETE /api/admin/notes/{id}/reject
Reject and delete a pending note (requires admin authentication).

**Response (200):**
```json
{
    "message": "Note rejected and deleted successfully"
}
```

### Filter Endpoints

#### GET /api/subjects
Get list of available subjects.

**Response (200):**
```json
{
    "subjects": ["Computer Science", "Mathematics", "Physics"]
}
```

#### GET /api/courses
Get list of available courses.

**Response (200):**
```json
{
    "courses": ["CS101", "MATH201", "PHYS101"]
}
```

#### GET /api/semesters
Get list of available semesters.

**Response (200):**
```json
{
    "semesters": ["Fall 2024", "Spring 2024", "Summer 2024"]
}
```

## Database Schema

The application uses SQLAlchemy ORM with the following database schema:

### Users Table

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | Integer | Primary Key, Auto Increment | Unique user identifier |
| username | String(80) | Unique, Not Null | User's chosen username |
| email | String(120) | Unique, Not Null | User's email address |
| password_hash | String(255) | Not Null | Hashed password |
| is_admin | Boolean | Default: False | Admin privileges flag |
| registration_date | DateTime | Default: Current Time | Account creation timestamp |

### Notes Table

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | Integer | Primary Key, Auto Increment | Unique note identifier |
| title | String(200) | Not Null | Note title |
| subject | String(100) | Not Null | Academic subject |
| course | String(100) | Not Null | Course identifier |
| semester | String(50) | Not Null | Academic semester |
| filename | String(255) | Not Null | Original filename |
| file_path | String(500) | Not Null | Server file path |
| file_type | String(10) | Not Null | File extension |
| description | Text | Nullable | Optional description |
| upload_date | DateTime | Default: Current Time | Upload timestamp |
| uploader_id | Integer | Foreign Key (users.id) | Uploader reference |
| is_approved | Boolean | Default: False | Approval status |
| download_count | Integer | Default: 0 | Download counter |

### Relationships

- **User to Notes**: One-to-Many relationship (one user can upload multiple notes)
- **Foreign Key**: `notes.uploader_id` references `users.id`

## User Guide

### Getting Started

#### 1. Registration
1. Navigate to the application homepage
2. Click "Join Now" or "Register"
3. Fill in the registration form with:
   - Username (minimum 3 characters)
   - Valid email address
   - Password (minimum 6 characters)
4. Click "Register" to create your account
5. You'll be redirected to the login page

#### 2. Login
1. Click "Login" from the navigation menu
2. Enter your username/email and password
3. Click "Login" to access your account
4. You'll be redirected to the homepage with authenticated features

### Using the Platform

#### Browsing Notes
1. Click "Browse Notes" from the navigation menu
2. Use the search bar to find specific notes by title or description
3. Apply filters by subject, course, or semester
4. Click "Apply Filters" to refine results
5. Browse through the paginated results
6. Click "Download" on any approved note to save it to your device

#### Uploading Notes
1. Ensure you're logged in
2. Click "Upload" from the navigation menu
3. Fill in the upload form:
   - **Title**: Descriptive title for your notes
   - **Subject**: Academic subject (e.g., "Computer Science")
   - **Course**: Course code or name (e.g., "CS101")
   - **Semester**: Academic term (e.g., "Fall 2024")
   - **Description**: Optional detailed description
   - **File**: Select your file (PDF, DOC, DOCX, PPT, PPTX)
4. Click "Upload Notes"
5. Your note will be submitted for admin approval

#### Managing Your Notes
1. Click "My Notes" from the navigation menu
2. View all your uploaded notes with their approval status
3. Monitor download counts for approved notes
4. See which notes are pending approval

### File Requirements

#### Supported Formats
- **PDF**: Portable Document Format
- **DOC**: Microsoft Word 97-2003
- **DOCX**: Microsoft Word 2007+
- **PPT**: Microsoft PowerPoint 97-2003
- **PPTX**: Microsoft PowerPoint 2007+

#### File Size Limits
- Maximum file size: 16MB per upload
- Recommended size: Under 10MB for faster uploads

#### Best Practices
- Use descriptive filenames
- Ensure files are not corrupted
- Include comprehensive metadata (title, subject, course, semester)
- Provide helpful descriptions for better discoverability

## Admin Guide

### Admin Access

Admin users have additional privileges for content moderation and system management.

#### Default Admin Account
- **Username**: `admin`
- **Password**: `admin123` (change immediately)
- **Email**: `admin@notessharing.com`

### Admin Functions

#### Content Moderation
1. Login with admin credentials
2. Click "Admin" from the navigation menu
3. Review pending notes in the "Pending Approval" tab
4. For each note, you can:
   - **Approve**: Make the note available for download
   - **Reject**: Delete the note and remove it from the system

#### Approval Process
When reviewing notes, consider:
- **Content Quality**: Is the content educational and well-formatted?
- **Appropriateness**: Does the content comply with academic standards?
- **File Integrity**: Is the file accessible and not corrupted?
- **Metadata Accuracy**: Are the subject, course, and semester correctly specified?

#### Best Practices for Admins
- Review uploads promptly to maintain user engagement
- Provide feedback for rejected content when possible
- Monitor system usage and user behavior
- Regularly backup the database and uploaded files
- Keep the admin password secure and change it regularly

### System Maintenance

#### Database Backup
Regular backups are essential for data protection:

```bash
# Backup SQLite database
cp src/database/app.db backup/app_backup_$(date +%Y%m%d).db

# Backup uploaded files
tar -czf backup/uploads_backup_$(date +%Y%m%d).tar.gz src/uploads/
```

#### Log Monitoring
Monitor application logs for errors and usage patterns:

```bash
# View Flask development logs
tail -f flask_app.log
```

#### Performance Optimization
- Regularly clean up old, unused files
- Monitor database size and optimize queries
- Consider implementing file compression for large uploads
- Set up proper caching for frequently accessed content

## Troubleshooting

### Common Issues and Solutions

#### 1. Application Won't Start

**Problem**: Flask application fails to start
**Solutions**:
- Verify Python version: `python --version` (should be 3.8+)
- Check virtual environment activation
- Reinstall dependencies: `pip install -r requirements.txt`
- Verify file permissions on the project directory

#### 2. Database Errors

**Problem**: Database connection or creation issues
**Solutions**:
- Ensure the `database` directory exists
- Check file permissions for database directory
- Delete existing database file and restart (will lose data)
- Verify SQLAlchemy installation: `pip show flask-sqlalchemy`

#### 3. File Upload Issues

**Problem**: Files fail to upload or save
**Solutions**:
- Create uploads directory: `mkdir -p src/uploads`
- Check file size (must be under 16MB)
- Verify file format (PDF, DOC, DOCX, PPT, PPTX only)
- Ensure sufficient disk space

#### 4. Authentication Problems

**Problem**: Login/logout not working properly
**Solutions**:
- Clear browser cookies and cache
- Check session configuration in Flask
- Verify CORS settings for cross-origin requests
- Restart the Flask application

#### 5. Frontend Not Loading

**Problem**: Web interface doesn't display correctly
**Solutions**:
- Check browser console for JavaScript errors
- Verify static files are being served correctly
- Clear browser cache
- Check network connectivity to the Flask server

#### 6. Permission Denied Errors

**Problem**: File system permission errors
**Solutions**:
- Check file and directory permissions
- Run with appropriate user privileges
- Ensure the uploads directory is writable
- Verify virtual environment permissions

### Debug Mode

Enable debug mode for detailed error information:

```python
# In src/main.py, change:
app.run(host='0.0.0.0', port=5000, debug=True)
```

**Warning**: Never enable debug mode in production environments.

### Getting Help

If you encounter issues not covered in this guide:

1. Check the browser console for JavaScript errors
2. Review Flask application logs
3. Verify all dependencies are correctly installed
4. Ensure file permissions are properly set
5. Test with a fresh virtual environment

### Performance Issues

#### Slow Upload/Download
- Check available disk space
- Verify network connectivity
- Consider file size optimization
- Monitor server resource usage

#### Database Performance
- Regular database maintenance
- Index optimization for search queries
- Consider upgrading to PostgreSQL for production use

## Contributing

### Development Setup

1. Fork the repository
2. Create a feature branch: `git checkout -b feature-name`
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Code Standards

- Follow PEP 8 for Python code
- Use meaningful variable and function names
- Add comments for complex logic
- Write unit tests for new features
- Update documentation for API changes

### Testing

Run tests before submitting changes:

```bash
# Install testing dependencies
pip install pytest pytest-flask

# Run tests
pytest tests/
```

### Security Considerations

- Never commit sensitive information (passwords, keys)
- Validate all user inputs
- Use HTTPS in production
- Implement proper authentication and authorization
- Regular security updates for dependencies

---

**Author**: Manus AI  
**Version**: 1.0.0  
**Last Updated**: 2024  
**License**: MIT License

For additional support or questions, please refer to the project documentation or contact the development team.

